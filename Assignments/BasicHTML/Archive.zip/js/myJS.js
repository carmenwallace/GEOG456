function daAlert(){
    var daTime = Date();
    alert("Hello, today is :"+ daTime);
}
